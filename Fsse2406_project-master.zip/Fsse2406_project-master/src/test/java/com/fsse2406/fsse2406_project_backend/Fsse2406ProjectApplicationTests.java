package com.fsse2406.fsse2406_project_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fsse2406ProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
