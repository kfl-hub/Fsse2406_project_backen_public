package com.fsse2406.fsse2406_project_backend.objects.transaction;

public enum Status {
    PREPARE,
    PROCESSING,
    SUCCESS,
    CANCELLED;
}
