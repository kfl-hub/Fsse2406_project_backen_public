package com.fsse2406.fsse2406_project_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fsse2406ProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(Fsse2406ProjectApplication.class, args);
    }

}
