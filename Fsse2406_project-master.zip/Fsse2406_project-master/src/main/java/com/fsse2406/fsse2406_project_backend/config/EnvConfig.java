package com.fsse2406.fsse2406_project_backend.config;

public class EnvConfig {
    public static  final String DEV_BSE_URL="http://localhost:5173";
    public static  final String PROD_BSE_URL="https://www.grabnrun.shop/";
}
